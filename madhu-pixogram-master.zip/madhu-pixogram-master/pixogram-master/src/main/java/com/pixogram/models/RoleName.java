package com.pixogram.models;

public enum  RoleName 
{
    ROLE_USER,
    ROLE_ADMIN;
}